<?php
/*不管浏览器是否支持，总之它就是CSS*/
function hu60_page_css(&$mime)
{
$mime='text/css';
return true;
}
