<?php
/*page异常类*/
class PageException extends Exception {
/*class end*/
 }