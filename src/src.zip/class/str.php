<?php
/*str类,字符串处理类*/
class str
{

protected static $星期=array('天','一','二','三','四','五','六','日');
/**
* 取得数字（0-6或1-7）对应的星期汉字
* 如果是0-6（用date('w')取得），0会得到“天”
* 如果是1-7（用date('N')取得，7会得到“日”）
* 所以可以自由选择使用“星期天”或“星期日”
*/
static function 星期($num) {
return self::$星期[$num];
 }
static function 时间差($t)
{
if($t<60) return $t.'秒';
$t=round($t/60);
if($t<60) return $t.'分钟';
$t=round($t/60);
if($t<24) return $t.'小时';
$t=round($t/24);
return $t.'天';
}
static function 匹配汉字($str,$extra='')
{
$preg='/^[\x{4e00}-\x{9fa5}'.$extra.']+$/u';
return preg_match($preg,$str);
}
static function npos($str,$substr,$times,$code='utf-8')
{
if($times<1)
 return false;
$len=mb_strlen($substr,$code);
for($off=-$len;$times>0;$times--)
 {
$off+=$len;
$off=mb_strpos($str,$substr,$off,$code);
 }
return $off;
}
static function word($f,$tolower=false)
{
$f=preg_replace('![^a-zA-Z0-9_\\-]!','',$f);
if($tolower)
 $f=strtolower($f);
return $f;
}
static function cut($str,$off,$len,$add='',$code='utf-8')

{
$slen=mb_strlen($str,$code);
if($off<0) $off=$slen-$off;
$str=mb_substr($str,$off,$len,$code);
if($off>0) $str=$add.$str;
if($off+$len<$slen) $str.=$add;
return $add;
}
//class str end
}
