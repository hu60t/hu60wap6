<?php
/*page异常类*/
class UserException extends Exception {
/*class end*/
 }